package com.sxhl.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class CkCodeAction extends ActionSupport implements ServletRequestAware,ServletResponseAware{
	
	private String yzm;	//�洢��֤��
	private HttpServletRequest request;	//�������
	private HttpServletResponse response;	//��Ӧ����
	
	public String getYzm() {
		return yzm;
	}
	public void setYzm(String yzm) {
		this.yzm = yzm;
	}

	public String checkCode() throws IOException{
		
		String read =  (String)ActionContext.getContext().getSession().get("rand");	//ȡ�����ɵ���֤��
		
		//�ж��û���֤�������Ƿ���ȷ
		if(!read.equals(yzm)){
			PrintWriter write = response.getWriter();
			write.print("false");	//����ȷ������false
		}
		return null;
	}
	
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}
	public void setServletResponse(HttpServletResponse response) {
		// TODO Auto-generated method stub
		this.response = response;
	}
}

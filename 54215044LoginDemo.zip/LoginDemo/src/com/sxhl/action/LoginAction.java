package com.sxhl.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;

import com.opensymphony.xwork2.ActionSupport;
import com.sxhl.bean.User;

public class LoginAction extends ActionSupport implements ServletRequestAware,ServletResponseAware{

	private HttpServletRequest request;
	private HttpServletResponse response;
	private User user;
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	public String login() throws IOException{
		response.setCharacterEncoding("utf-8");
		PrintWriter write = response.getWriter();
		
		if("admin".equals(user.getName())){
			if("123".equals(user.getPwd())){
				
				write.print("{\"userName\":\""+user.getName()+"\",\"pdName\":\"��ˮƤ��\",\"pdCount\":\"40\",\"pdPrice\":\"��300\"}");
				write.flush();
				write.close();
				return null;
			}
		}
		write.print("false");
		write.flush();
		write.close();
		return null;
	}

	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		this.request = arg0;
	}

	public void setServletResponse(HttpServletResponse arg0) {
		// TODO Auto-generated method stub
		this.response = arg0;
	}
}
